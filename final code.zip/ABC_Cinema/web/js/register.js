
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDpShG2QRNKrFamjHSp1PiXyCyG05v4QGw",
    authDomain: "abc-cinema-187b9.firebaseapp.com",
    projectId: "abc-cinema-187b9",
    storageBucket: "abc-cinema-187b9.firebasestorage.app",
    messagingSenderId: "935706707712",
    appId: "1:935706707712:web:a7b41f4bcdfb222688d5e5",
    measurementId: "G-6H3MFNKR0T"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
