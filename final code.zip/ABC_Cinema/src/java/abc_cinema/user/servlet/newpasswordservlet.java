package abc_cinema.user.servlet;

import abc_cinema.db.connection.ConnectionDB;
import abc_cinema.user.dao.UserDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/User/newpasswordservlet")
public class newpasswordservlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String newPassword = request.getParameter("password");
        String confPassword = request.getParameter("confPassword");
        String email = (String) session.getAttribute("email");
        RequestDispatcher dispatcher = null;

        if (newPassword != null && confPassword != null && newPassword.equals(confPassword)) {
            // Validate password strength if necessary
            try (Connection con = ConnectionDB.getCon()) {
                UserDao userDao = new UserDao(con);
                boolean isUpdated = userDao.updatePassword(email, newPassword);

                if (isUpdated) {
                    request.setAttribute("status", "resetSuccess");
                    dispatcher = request.getRequestDispatcher("userlogin.jsp");
                } else {
                    request.setAttribute("status", "resetFailed");
                    dispatcher = request.getRequestDispatcher("newpassword.jsp");
                }
                dispatcher.forward(request, response);

            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                request.setAttribute("status", "error");
                dispatcher = request.getRequestDispatcher("error.jsp");
                dispatcher.forward(request, response);
            }
        } else {
            request.setAttribute("status", "passwordMismatch");
            dispatcher = request.getRequestDispatcher("newpassword.jsp");
            dispatcher.forward(request, response);
        }
    }
}
