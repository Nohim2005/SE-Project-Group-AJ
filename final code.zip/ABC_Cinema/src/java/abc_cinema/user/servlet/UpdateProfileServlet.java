package abc_cinema.user.servlet;

import abc_cinema.user.dao.UserDao;
import abc_cinema.user.model.User;
import abc_cinema.db.connection.ConnectionDB;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;

@WebServlet("/User/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User loggedInUser = (User) session.getAttribute("user");

        if (loggedInUser == null) {
            response.sendRedirect("userlogin.jsp");
            return;
        }

        String newName = request.getParameter("username");
        String newPassword = request.getParameter("password");

        // Validate input
        if (newName == null || newName.trim().isEmpty() || newPassword == null || newPassword.trim().isEmpty()) {
            request.setAttribute("error", "Username and password cannot be empty.");
            request.getRequestDispatcher("updateprofile.jsp").forward(request, response);
            return;
        }

        try (Connection con = ConnectionDB.getCon()) {
            UserDao userDao = new UserDao(con);

            boolean updateSuccessful = userDao.updateUserProfile(loggedInUser.getEmail(), newName, newPassword);

            if (updateSuccessful) {
                loggedInUser.setName(newName);
                session.setAttribute("user", loggedInUser);

                // Set success message and forward to updateprofile.jsp
                request.setAttribute("message", "Profile has been updated successfully!");
                request.getRequestDispatcher("updateprofile.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Failed to update profile. Please try again.");
                request.getRequestDispatcher("updateprofile.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred. Please try again later.");
            request.getRequestDispatcher("updateprofile.jsp").forward(request, response);
        }
    }
}


