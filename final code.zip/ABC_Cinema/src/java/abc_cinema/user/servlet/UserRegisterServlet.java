package abc_cinema.user.servlet;

import abc_cinema.user.dao.UserDao;
import abc_cinema.db.connection.ConnectionDB;

import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Handles user registration requests.
 */
public class UserRegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve form data
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String dob = request.getParameter("dob");
            String gender = request.getParameter("gender");

            // Store user details in the database using UserDao
            UserDao userDao = new UserDao(ConnectionDB.getCon());
            
            boolean isRegistered = userDao.registerUser(name, email, password, dob, gender);

            if (isRegistered) {
                // Registration successful, redirect to login page
                response.sendRedirect("userlogin.jsp");
            } else {
                // Registration failed, show error message
                String errorMessage = "User is already Registered";
                HttpSession regSession = request.getSession();
                request.setAttribute("errorMessage", errorMessage);
                //equest.getRequestDispatcher("userregister.jsp").forward(request, response);
                response.sendRedirect("register.jsp");
            }
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred during registration.");
        }
    }
}
