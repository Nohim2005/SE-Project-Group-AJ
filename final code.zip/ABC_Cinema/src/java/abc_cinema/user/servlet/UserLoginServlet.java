package abc_cinema.user.servlet;

import abc_cinema.user.dao.UserDao;
import abc_cinema.user.model.User;
import abc_cinema.db.connection.ConnectionDB;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Handles login requests for users.
 */
public class UserLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve user input from the login form
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // Validate credentials using UserDao
            UserDao userDao = new UserDao(ConnectionDB.getCon());
            User user = userDao.logUser(email, password);

            if (user != null) {
                // Valid user: create session and redirect to user dashboard
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                response.sendRedirect("userpanel.jsp");
            } else {
                // Invalid credentials: return to login page with error
                String message = "<div class=\"infomsg\">Invalid Email or Password, Please try again.</div>";
                request.setAttribute("errorMessage", message );
                request.getRequestDispatcher("userlogin.jsp").forward(request, response);
                
            }
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(UserLoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            // Show a generic error message
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while processing your request. Please try again later.");
        }
    }
}
