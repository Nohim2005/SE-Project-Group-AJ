/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

/**
 *
 * @author Chani
 */
package abc_cinema.user.services;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;



//@WebServlet(name = "SendContactServlet", urlPatterns = {"/SendContactServlet"})
public class SendContactServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           // Retrieve form inputs
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String subject = request.getParameter("subject");
        String messageText = request.getParameter("message");

        // Define recipient and email details
        final String from = "chanithuef@gmail.com"; // Replace with your email
        final String password = "behv qsuv bdeu rqgt"; // Use an app password for Gmail
        String to = "chanithuef@gmail.com"; // Email to receive the contact message
        

        // SMTP server details
        String host = "smtp.gmail.com";
        String port = "587";

        // Set up properties for the session
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);

        // Create a session with an authenticator
        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            // Create email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(email, name));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setReplyTo(new InternetAddress[] { new InternetAddress(email) });
            // Format the message body
             String formattedMessage = "You have a new contact form submission:\n\n"
                    + "Name: " + name + "\n"
                    + "Email: " + email + "\n"
                    + "Subject: " + subject + "\n"
                    + "Message: \n" + messageText;

            message.setText(formattedMessage);

            // Send the email
            Transport.send(message);

            // Send response to the user
            response.getWriter().println("Thank you, " + name + ". Your message has been sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred while sending the email. Please try again later.");
        }
    }
}