package abc_cinema.user.dao;

import abc_cinema.user.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object for user-related operations.
 */
public class UserDao {

    private final Connection con;

    
    public UserDao(Connection con) {
        this.con = con;
    }

    

    public boolean registerUser(String name, String email, String password, String dob, String gender) throws SQLException {

        String query = "INSERT INTO user (name, email, password, dob, gender) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, password); 
            pst.setString(4, dob);
            pst.setString(5, gender);

            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        }
        
    }
    
    public boolean updateUserProfile(String email, String newName, String newPassword) throws SQLException {
        String query = "UPDATE user SET name = ?, password = ? WHERE email = ?";
        try (PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, newName);
            pst.setString(2, newPassword);
            pst.setString(3, email);

            int rowsAffected = pst.executeUpdate();
            System.out.println("Profile update rows affected: " + rowsAffected); // Debugging
            return rowsAffected > 0;
        }
    }
    
    public boolean updatePassword(String email, String newPassword) throws SQLException {
        String query = "UPDATE user SET password = ? WHERE email = ?";
        try (PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, newPassword); // Set the new password
            pst.setString(2, email); // Set the email for identification

            int rowsUpdated = pst.executeUpdate(); // Execute the update query

            return rowsUpdated > 0; // Return true if at least one row was updated
        }
    }
    
    
    public User logUser(String email, String password) throws SQLException {
        User user = null;

        // SQL query to select user by email and password
        String query = "SELECT * FROM user WHERE email = ? AND password = ?";
        
        try (PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, email);
            pst.setString(2, password);  

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    // Map the result set to a User object
                    user = new User();
                    user.setId(rs.getInt("uid"));
                    user.setName(rs.getString("name"));
                    user.setEmail(rs.getString("email"));
                    user.setDob(rs.getString("dob"));
                    user.setGender(rs.getString("gender"));  
                }
            }
        }

        return user;
    }
}

