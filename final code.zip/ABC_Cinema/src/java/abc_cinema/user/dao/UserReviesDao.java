/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.user.dao;

/**
 *
 * @author Chani
 */
public class UserReviesDao {
    private int rid;
    private String username;
    private int uid;
    private String reveiw;

    public int getRid() {
        return rid;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getReveiw() {
        return reveiw;
    }

    public void setReveiw(String reveiw) {
        this.reveiw = reveiw;
    }
}
