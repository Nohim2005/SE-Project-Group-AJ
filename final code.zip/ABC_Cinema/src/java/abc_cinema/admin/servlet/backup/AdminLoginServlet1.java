/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package abc_cinema.admin.servlet.backup;

import abc_cinema.admin.dao.AdminDao;
import abc_cinema.admin.model.Admin;
import abc_cinema.db.connection.ConnectionDB;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Chani
 */
public class AdminLoginServlet1 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AdminLoginServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AdminLoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            try (PrintWriter out = response.getWriter()) {
                String email = request.getParameter("email");
                String password = request.getParameter("pass");
                
                //out.println(email + "  " + password);
                
                    AdminDao ado = new AdminDao(ConnectionDB.getCon()); 
                    Admin admin = ado.logAdmin(email, password); 
                    if (admin != null) { 
                        //response.getWriter().println("Welcome, " + admin.getName()); 
                        response.sendRedirect("adminpanel.jsp");
                    } else { 
                        response.getWriter().println("unknown credentials");
                    } 
        
    }   catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(AdminLoginServlet1.class.getName()).log(Level.SEVERE, null, ex);
        }

    

    }
}
