/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package abc_cinema.admin.services;

import abc_cinema.admin.model.Admin;

/**
 *
 * @author Chani
 */
public interface AdminService {
    public Admin logAdmin(String email, String password);
}
