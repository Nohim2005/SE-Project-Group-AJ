/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.admin.services;

import abc_cinema.db.connection.ConnectionDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteMovieServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Retrieve the movie ID from the request
            String movieIdParam = request.getParameter("mid");
            if (movieIdParam == null || movieIdParam.isEmpty()) {
                response.getWriter().write("Error: Movie ID is missing.");
                return;
            }

            int movieId = Integer.parseInt(movieIdParam);

            // Connect to the database
            try (Connection con = ConnectionDB.getCon()) {
                String query = "DELETE FROM movie WHERE mid = ?";
                try (PreparedStatement pst = con.prepareStatement(query)) {
                    pst.setInt(1, movieId);

                    int rowsAffected = pst.executeUpdate();

                    if (rowsAffected > 0) {
                    // If update is successful, forward the request to ManageMovies servlet
                    ManageMovies manageMovies = new ManageMovies();
                    manageMovies.doGet(request, response);
                } else {
                    response.getWriter().write("Error: Could not delete movie.");
                }
                }
            }
        } catch (NumberFormatException e) {
            response.getWriter().write("Error: Invalid movie ID format.");
        } catch (SQLException | ClassNotFoundException e) {
            throw new ServletException(e);
        }
    }
}

