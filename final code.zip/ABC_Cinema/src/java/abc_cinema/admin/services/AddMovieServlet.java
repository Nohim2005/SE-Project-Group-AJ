/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.admin.services;
import abc_cinema.db.connection.ConnectionDB;
/**
 *
 * @author Chani
 */
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class AddMovieServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get form data
        String name = request.getParameter("name");
        String director = request.getParameter("director");
        String releasedate = request.getParameter("releasedate");
        releasedate = releasedate.replace(".", "-");
        String cast = request.getParameter("cast");
        String description = request.getParameter("description");
        String poster = request.getParameter("poster");
        String durationStr = request.getParameter("duration");
        String trailer = request.getParameter("trailer");
        String upcomingStr = request.getParameter("upcoming");
        String categories = request.getParameter("categories");
        String rating = request.getParameter("rating");

        // Validate form data
        if (name == null || name.isEmpty() || director == null || director.isEmpty()) {
            request.setAttribute("errorMessage", "Name and director are required fields.");
            request.getRequestDispatcher("errorPage.jsp").forward(request, response);
            return;
        }

        // Convert numeric values
        int duration = 0;
        int upcoming = 0;
        try {
            duration = Integer.parseInt(durationStr);
            upcoming = Integer.parseInt(upcomingStr);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Invalid duration or upcoming value.");
            request.getRequestDispatcher("errorPage.jsp").forward(request, response);
            return;
        }

        // Prepare SQL query
        String sql = "INSERT INTO movie (name, director, releasedate, cast, description, poster, duration, trailer, upcoming, categories, rating) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Database connection
        try (Connection con = ConnectionDB.getCon()) {
            if (con == null) {
                request.setAttribute("errorMessage", "Database connection failed.");
                request.getRequestDispatcher("errorPage.jsp").forward(request, response);
                return;
            }

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                // Set query parameters
                pst.setString(1, name);
                pst.setString(2, director);
                pst.setString(3, releasedate);
                pst.setString(4, cast);
                pst.setString(5, description);
                pst.setString(6, poster);
                pst.setInt(7, duration);
                pst.setString(8, trailer);
                pst.setInt(9, upcoming);
                pst.setString(10, categories);
                pst.setString(11, rating);

                int rowsInserted = pst.executeUpdate();
                if (rowsInserted > 0) {
                    // Redirect to manage_movie page on success
                    response.sendRedirect("manage_movie.jsp"); // Redirect after successful insertion
                } else {
                    response.getWriter().write("Failed to add the movie. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.getWriter().write("Database error: " + e.getMessage());
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database error: " + e.getMessage());
        }
    }
}
