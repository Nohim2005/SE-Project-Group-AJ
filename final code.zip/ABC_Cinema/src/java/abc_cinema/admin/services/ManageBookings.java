/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.admin.services;
import abc_cinema.db.connection.ConnectionDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


/**
 *
 * @author Chani
 */
public class ManageBookings extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        try (Connection con = ConnectionDB.getCon()) {
            if ("add".equals(action)) {
                // Add a new booking
                String seat = request.getParameter("seat");
                int user_id = Integer.parseInt(request.getParameter("user_id"));
                int show_id = Integer.parseInt(request.getParameter("show_id"));
                String show_time = request.getParameter("show_time");
                String show_name = request.getParameter("show_name");
               
                double amount_paid = Double.parseDouble(request.getParameter("amount_paid"));
                
                String addQuery = "INSERT INTO bookings (seat, user_id, show_id, show_time, show_name, amount_paid) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pst = con.prepareStatement(addQuery)) {
                    pst.setString(1, seat);
                    pst.setInt(2, user_id);
                    pst.setInt(3, show_id);
                    pst.setString(4, show_time);
                    pst.setString(5, show_name);
       
                    pst.setDouble(6, amount_paid);
                    pst.executeUpdate();
                }
                response.sendRedirect("DisplayBookings"); // Redirect after adding
            } else if ("edit".equals(action)) {
                // Edit existing booking
                int booking_id = Integer.parseInt(request.getParameter("booking_id"));
                String seat = request.getParameter("seat");
                int user_id = Integer.parseInt(request.getParameter("user_id"));
                int show_id = Integer.parseInt(request.getParameter("show_id"));
                String show_time = request.getParameter("show_time");
                String show_name = request.getParameter("show_name");
                String booking_time = request.getParameter("booking_time");
                double amount_paid = Double.parseDouble(request.getParameter("amount_paid"));

                String editQuery = "UPDATE bookings SET seat=?, user_id=?, show_id=?, show_time=?, show_name=?, booking_time=?, amount_paid=? WHERE booking_id=?";
                try (PreparedStatement pst = con.prepareStatement(editQuery)) {
                    pst.setString(1, seat);
                    pst.setInt(2, user_id);
                    pst.setInt(3, show_id);
                    pst.setString(4, show_time);
                    pst.setString(5, show_name);
                    pst.setString(6, booking_time);
                    pst.setDouble(7, amount_paid);
                    pst.setInt(8, booking_id);
                    pst.executeUpdate();
                }
                response.sendRedirect("DisplayBookings"); // Redirect after editing
            } else if ("delete".equals(action)) {
                // Delete booking
                int booking_id = Integer.parseInt(request.getParameter("booking_id"));
                String deleteQuery = "DELETE FROM bookings WHERE booking_id=?";
                try (PreparedStatement pst = con.prepareStatement(deleteQuery)) {
                    pst.setInt(1, booking_id);
                    pst.executeUpdate();
                }
                response.sendRedirect("DisplayBookings"); // Redirect after deleting
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }
}