/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.admin.services;

import abc_cinema.db.connection.ConnectionDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import abc_cinema.admin.services.ManageMovies;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EditMovieServlet extends HttpServlet {

    @Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    try {
        // Fetch the parameters from the form
        int movieId = Integer.parseInt(request.getParameter("mid"));
        String name = request.getParameter("name");
        String director = request.getParameter("director");
        String releaseDate = request.getParameter("releasedate");
        String cast = request.getParameter("cast");
        String description = request.getParameter("description");
        String poster = request.getParameter("poster");
        String duration = request.getParameter("duration"); // Duration is a string
        String trailer = request.getParameter("trailer");

        // Check if the 'upcoming' parameter is present, else set to a default value (e.g., 0)
        String upcomingParam = request.getParameter("upcoming");
        int upcoming = (upcomingParam != null && !upcomingParam.isEmpty()) ? Integer.parseInt(upcomingParam) : 0;

        String categories = request.getParameter("categories");
        String rating = request.getParameter("rating");

        // Use JDBC to update the movie in the database
        try (Connection con = ConnectionDB.getCon()) {
            String query = "UPDATE movie SET name = ?, director = ?, releasedate = ?, cast = ?, description = ?, "
                    + "poster = ?, duration = ?, trailer = ?, upcoming = ?, categories = ?, rating = ? WHERE mid = ?";

            try (PreparedStatement pst = con.prepareStatement(query)) {
                // Set the parameters for the update query
                pst.setString(1, name);
                pst.setString(2, director);
                pst.setString(3, releaseDate);
                pst.setString(4, cast);
                pst.setString(5, description);
                pst.setString(6, poster);
                pst.setString(7, duration); // Duration is a string
                pst.setString(8, trailer);
                pst.setInt(9, upcoming);
                pst.setString(10, categories);
                pst.setString(11, rating);
                pst.setInt(12, movieId);

                int rowsAffected = pst.executeUpdate();
                if (rowsAffected > 0) {
                    // If update is successful, forward the request to ManageMovies servlet
                    ManageMovies manageMovies = new ManageMovies();
                    manageMovies.doGet(request, response);
                } else {
                    response.getWriter().write("Error: Could not update movie.");
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new ServletException(e);
        }
    } catch (NumberFormatException | NullPointerException e) {
        response.sendRedirect("manage_movie.jsp?error=1");
    }
}
}


