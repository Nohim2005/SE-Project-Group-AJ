package abc_cinema.admin.services;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chani
 */

import abc_cinema.db.connection.ConnectionDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/MovieAdminServlet")
public class MovieAdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        int id = request.getParameter("id") != null ? Integer.parseInt(request.getParameter("id")) : 0;

        String name = request.getParameter("name");
        String director = request.getParameter("director");
        String releasedate = request.getParameter("releasedate");
        String cast = request.getParameter("cast");
        String description = request.getParameter("description");
        String poster = request.getParameter("poster");
        String duration = request.getParameter("duration");
        String trailer = request.getParameter("trailer");
        String upcoming = request.getParameter("upcoming");
        String categories = request.getParameter("categories");
        String rating = request.getParameter("rating");
        try {
            Connection con = ConnectionDB.getCon();

            if ("insert".equals(action)) {
                String query = "INSERT INTO movies (name, director, releasedate, cast, description, poster, duration, trailer, categories, rating, upcoming) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, name);
                ps.setString(2, director);
                ps.setString(3, releasedate);
                ps.setString(4, cast);
                ps.setString(5, description);
                ps.setString(6, poster);
                ps.setString(7, duration);
                ps.setString(8, trailer);
                ps.setString(9, categories);
                ps.setString(10, rating);
                ps.setString(11, categories);
                ps.executeUpdate();

            } else if ("update".equals(action)) {
                String query = "UPDATE movies SET name=?, director=?, releasedate=?, cast=?, description=?, poster=?, duration=?, trailer=?, rating=?, categories=?, upcoming=? WHERE id=?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, name);
                ps.setString(2, director);
                ps.setString(3, releasedate);
                ps.setString(4, cast);
                ps.setString(5, description);
                ps.setString(6, poster);
                ps.setString(7, duration);
                ps.setString(8, trailer);
                ps.setString(9, categories);
                ps.setString(10, rating);
                ps.setString(11, upcoming);
                ps.setInt(11, id);
                ps.executeUpdate();

            } else if ("delete".equals(action)) {
                String query = "DELETE FROM movies WHERE id=?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, id);
                ps.executeUpdate();
            }

            con.close();
            response.sendRedirect("admin.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
