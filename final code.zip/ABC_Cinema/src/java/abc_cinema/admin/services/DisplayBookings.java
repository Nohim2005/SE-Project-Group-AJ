/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.admin.services;

import abc_cinema.db.connection.ConnectionDB;
import abc_cinema.movie.dao.Bookings;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Chani
 */
public class DisplayBookings extends HttpServlet {
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Bookings> bookings = new ArrayList<>();
     
        try (Connection con = ConnectionDB.getCon(); 
             PreparedStatement pst = con.prepareStatement("SELECT * FROM bookings"); 
             ResultSet rs = pst.executeQuery()) {

            // Retrieve booking records
            while (rs.next()) {
                Bookings booking = new Bookings();
                booking.setBooking_id(rs.getInt("booking_id"));
                booking.setUser_id(rs.getInt("user_id"));
                booking.setShow_id(rs.getInt("show_id"));
                booking.setSeat(rs.getString("seat"));
                booking.setShow_time(rs.getString("show_time"));
                booking.setShow_name(rs.getString("show_name"));
                booking.setBooking_time(rs.getString("booking_time"));
                booking.setAmount_paid(rs.getDouble("amount_paid"));

                bookings.add(booking);
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }

        // Set the bookings list as a request attribute and forward to the JSP
        request.setAttribute("bookings", bookings);
        request.getRequestDispatcher("manage_bookings.jsp").forward(request, response);
    }
}