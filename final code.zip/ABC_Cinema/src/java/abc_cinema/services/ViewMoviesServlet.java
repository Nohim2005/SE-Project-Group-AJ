package abc_cinema.services;

/**
 *
 * @author Chani
 */

import abc_cinema.db.connection.ConnectionDB;
import abc_cinema.movie.dao.Movie;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class ViewMoviesServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("ViewMoviesServlet executed!");

    List<Movie> movies = new ArrayList<>();
    try (Connection con = ConnectionDB.getCon();
         PreparedStatement pst = con.prepareStatement("SELECT * FROM movie");
         ResultSet rs = pst.executeQuery()) {

        System.out.println("Database connection successful: " + (con != null));
        response.getWriter().println("Servlet executed successfully!");
        response.getWriter().println("Movies size: " + movies.size());

        while (rs.next()) {
            Movie movie = new Movie();
            movie.setMid(rs.getInt("mid"));
            movie.setName(rs.getString("name"));
            movie.setDirector(rs.getString("director"));
            movie.setReleasedate(rs.getString("releasedate"));
            movie.setCast(rs.getString("cast"));
            movie.setDescription(rs.getString("description"));
            movie.setPoster(rs.getString("poster"));
            movie.setDuration(rs.getInt("duration"));
            movie.setTrailer(rs.getString("trailer"));
            movie.setUpcoming(rs.getInt("upcoming"));
            movie.setCategories(rs.getString("categories"));
            movie.setRating(rs.getString("rating"));

            movies.add(movie);
        }
        System.out.println("Movies retrieved: " + movies.size());
    } catch (Exception e) {
        e.printStackTrace();
        response.getWriter().write("Error: " + e.getMessage());
    }

    request.setAttribute("movies", movies);
    request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}