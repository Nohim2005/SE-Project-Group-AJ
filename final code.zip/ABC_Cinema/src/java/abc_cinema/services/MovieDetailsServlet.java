/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_cinema.services;

/**
 *
 * @author Chani
 */
import abc_cinema.db.connection.ConnectionDB;
import abc_cinema.movie.dao.Movie;
import abc_cinema.movie.dao.ShowTimes;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MovieDetailsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String movieId = request.getParameter("mid");
        if (movieId == null || movieId.isEmpty()) {
            response.sendRedirect("/ABC_Cinema");
            return;
        }
        Movie movie = null;
        List<ShowTimes> showTimesList = new ArrayList<>();

        try (Connection con = ConnectionDB.getCon();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM movie WHERE mid = ?")) {

            pst.setInt(1, Integer.parseInt(movieId));
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    movie = new Movie();
                    movie.setMid(rs.getInt("mid"));
                    movie.setName(rs.getString("name"));
                    movie.setDirector(rs.getString("director"));
                    movie.setReleasedate(rs.getString("releasedate"));
                    movie.setCast(rs.getString("cast"));
                    movie.setDescription(rs.getString("description"));
                    movie.setPoster(rs.getString("poster"));
                    movie.setDuration(rs.getInt("duration"));
                    movie.setTrailer(rs.getString("trailer"));
                    movie.setUpcoming(rs.getInt("upcoming"));
                    movie.setCategories(rs.getString("categories"));
                    movie.setRating(rs.getString("rating"));
                }
            }
        
        // Fetch showtimes for the movie
            try (PreparedStatement showTimesPst = con.prepareStatement("SELECT * FROM shows_times WHERE movie_id = ?")) {
                showTimesPst.setInt(1, Integer.parseInt(movieId));
                try (ResultSet showTimesRs = showTimesPst.executeQuery()) {
                    while (showTimesRs.next()) {
                        ShowTimes show = new ShowTimes();
                        show.setShow_id(showTimesRs.getInt("show_id"));
                        show.setMovie_id(showTimesRs.getInt("movie_id"));
                        show.setTheater_id(showTimesRs.getInt("theater_id"));
                        show.setShow_time(showTimesRs.getString("show_time"));
                        show.setShow_date(showTimesRs.getString("show_date"));
                        show.setPrice(showTimesRs.getInt("price"));
                        showTimesList.add(show);
                    }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
            return;
        }

        if (movie != null) {
            request.setAttribute("movie", movie);
            request.setAttribute("showTimesList", showTimesList);
            request.getRequestDispatcher("MovieDetails.jsp").forward(request, response);
        } else {
            response.getWriter().write("Movie not found!");
        }
    }
}
