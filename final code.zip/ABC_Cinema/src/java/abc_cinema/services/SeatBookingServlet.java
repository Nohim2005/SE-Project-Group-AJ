package abc_cinema.services;

/**
 *
 * @author Chani
 */

import abc_cinema.db.connection.ConnectionDB;
import abc_cinema.movie.dao.Movie;
import abc_cinema.movie.dao.ShowTimes;
import abc_cinema.movie.dao.Bookings;
import abc_cinema.movie.dao.Seats;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class SeatBookingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String movieId = request.getParameter("mid");
        if (movieId == null || movieId.isEmpty()) {
            response.sendRedirect("/ABC_Cinema");
            return;
        }

        Movie movie = null;
        List<ShowTimes> showTimesList = new ArrayList<>();
        List<Bookings> bookedSeatsList = new ArrayList<>();

        try (Connection con = ConnectionDB.getCon()) {
            // Fetch movie details
            try (PreparedStatement moviePst = con.prepareStatement("SELECT * FROM movie WHERE mid = ?")) {
                moviePst.setInt(1, Integer.parseInt(movieId));
                try (ResultSet movieRs = moviePst.executeQuery()) {
                    if (movieRs.next()) {
                        movie = new Movie();
                        movie.setMid(movieRs.getInt("mid"));
                        movie.setName(movieRs.getString("name"));
                        movie.setDirector(movieRs.getString("director"));
                        movie.setReleasedate(movieRs.getString("releasedate"));
                        movie.setCast(movieRs.getString("cast"));
                        movie.setDescription(movieRs.getString("description"));
                        movie.setPoster(movieRs.getString("poster"));
                        movie.setDuration(movieRs.getInt("duration"));
                        movie.setTrailer(movieRs.getString("trailer"));
                        movie.setUpcoming(movieRs.getInt("upcoming"));
                        movie.setCategories(movieRs.getString("categories"));
                        movie.setRating(movieRs.getString("rating"));
                    }
                }
            }

            // Fetch showtimes for the movie
            try (PreparedStatement showTimesPst = con.prepareStatement("SELECT * FROM shows_times WHERE movie_id = ?")) {
                showTimesPst.setInt(1, Integer.parseInt(movieId));
                try (ResultSet showTimesRs = showTimesPst.executeQuery()) {
                    while (showTimesRs.next()) {
                        ShowTimes show = new ShowTimes();
                        show.setShow_id(showTimesRs.getInt("show_id"));
                        show.setPrice(showTimesRs.getInt("price"));
                        showTimesList.add(show);
                    }
                }
            }
             
            // Retrieve show_id (e.g., from request parameter)
            String show_id = request.getParameter("show_id");
            if (show_id == null || show_id.isEmpty()) {
                throw new IllegalArgumentException("Show ID is missing.");
            }

            // Declare the list to hold the bookings
           

            try {
                // Query to get seat_id from bookings for the specific show_id
                String bookingsQuery = "SELECT seat FROM bookings WHERE show_id = ?";
                try (PreparedStatement bookedSeatsPst = con.prepareStatement(bookingsQuery)) {
                    bookedSeatsPst.setInt(1, Integer.parseInt(show_id));
                    
                    // Execute the query
                    try (ResultSet rs = bookedSeatsPst.executeQuery()) {
                        while (rs.next()) {
                            //String seat = rs.getString("seat");
                            //bookedSeatsList.add(seat);
                            Bookings booking = new Bookings(); // No-arg constructor
                            booking.setSeat(rs.getString("seat")); // Use the setter method to set the seat
                            bookedSeatsList.add(booking); // Add to the list
                            
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().write("Error: " + e.getMessage());
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
            return;
        }

        // Check if movie details were found
        if (movie == null) {
            response.getWriter().write("Movie not found!");
            return;
        }

        // Set attributes and forward to the JSP
        request.setAttribute("movie", movie);
        request.setAttribute("showTimesList", showTimesList);
        request.setAttribute("bookedSeatsList", bookedSeatsList);
        request.getRequestDispatcher("seats.jsp").forward(request, response);
    }
}
