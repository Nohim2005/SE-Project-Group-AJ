package abc_cinema.user.services;

import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.auth.http.HttpCredentialsAdapter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import javax.mail.*;
import javax.mail.internet.*;
import java.io.*;
import java.util.Base64;
import java.util.Properties;

@WebServlet("/SendContactServlet")
public class SendContactServlet extends HttpServlet {
    private static final String APPLICATION_NAME = "Gmail API Java";
    private static final String CREDENTIALS_FILE_PATH = "C:\\Users\\Chani\\OneDrive\\Documents\\NetBeansProjects\\ABC_Cinema last build mine\\ABC_Cinema\\Resources/client_secret_784473905308-lk97hbb8ssch08it9h5g4lev6skjldhd.apps.googleusercontent.com.json"; // Path to your JSON file
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");

        // Email content
        String emailSubject = "Contact Form: " + subject;
        String emailBody = "Name: " + name + "\n" + "Email: " + email + "\n" + "Message:\n" + message;

        try {
            // Create Gmail service
            Gmail service = getGmailService();
            
            // Create and send email
            MimeMessage emailMessage = createEmail("recipient-email@gmail.com", "your-email@gmail.com", emailSubject, emailBody, email);
            sendMessage(service, "me", emailMessage);
            response.getWriter().println("Message sent successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error sending message: " + e.getMessage());
        }
    }

    private static Gmail getGmailService() throws Exception {
        GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(CREDENTIALS_FILE_PATH))
            .createScoped("https://www.googleapis.com/auth/gmail.send");

        return new Gmail.Builder(
            GoogleNetHttpTransport.newTrustedTransport(),
            JSON_FACTORY,
            new HttpCredentialsAdapter(credentials)) // Pass as HttpRequestInitializer
            .setApplicationName(APPLICATION_NAME)
            .build();
}

    private static MimeMessage createEmail(String to, String from, String subject, String bodyText, String replyTo) throws MessagingException {
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);
        MimeMessage email = new MimeMessage(session);

        email.setFrom(new InternetAddress(from));
        email.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(to));
        email.setSubject(subject);
        email.setText(bodyText);
        
    if (replyTo != null && !replyTo.isEmpty()) {
        email.setReplyTo(new Address[]{new InternetAddress(replyTo)});
    }
        
        return email;
    }

    private static void sendMessage(Gmail service, String userId, MimeMessage email) throws MessagingException, IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        email.writeTo(buffer);
        byte[] rawMessage = buffer.toByteArray();
        String encodedEmail = Base64.getUrlEncoder().encodeToString(rawMessage);

        Message message = new Message();
        message.setRaw(encodedEmail);

        service.users().messages().send(userId, message).execute();
    }
}
